import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5a25f4a0 = () => interopDefault(import('../pages/blog/index.vue' /* webpackChunkName: "pages/blog/index" */))
const _49495806 = () => interopDefault(import('../pages/brends/index.vue' /* webpackChunkName: "pages/brends/index" */))
const _b9d70ac4 = () => interopDefault(import('../pages/cart/index.vue' /* webpackChunkName: "pages/cart/index" */))
const _443e077a = () => interopDefault(import('../pages/compare.vue' /* webpackChunkName: "pages/compare" */))
const _63dbba34 = () => interopDefault(import('../pages/consulting/index.vue' /* webpackChunkName: "pages/consulting/index" */))
const _287d9d00 = () => interopDefault(import('../pages/designers/index.vue' /* webpackChunkName: "pages/designers/index" */))
const _5ec18b57 = () => interopDefault(import('../pages/favorite.vue' /* webpackChunkName: "pages/favorite" */))
const _884189cc = () => interopDefault(import('../pages/cart/order.vue' /* webpackChunkName: "pages/cart/order" */))
const _857d5154 = () => interopDefault(import('../pages/catalog/search/notfind.vue' /* webpackChunkName: "pages/catalog/search/notfind" */))
const _20407fc0 = () => interopDefault(import('../pages/catalog/collection/view/_id.vue' /* webpackChunkName: "pages/catalog/collection/view/_id" */))
const _3cba7220 = () => interopDefault(import('../pages/catalog/tile/view/_id.vue' /* webpackChunkName: "pages/catalog/tile/view/_id" */))
const _dc0aab0c = () => interopDefault(import('../pages/catalog/collection/_id.vue' /* webpackChunkName: "pages/catalog/collection/_id" */))
const _3b0b7134 = () => interopDefault(import('../pages/catalog/search/_name.vue' /* webpackChunkName: "pages/catalog/search/_name" */))
const _5ab4a54a = () => interopDefault(import('../pages/catalog/tile/_id.vue' /* webpackChunkName: "pages/catalog/tile/_id" */))
const _28e5a641 = () => interopDefault(import('../pages/catalog/view/_id.vue' /* webpackChunkName: "pages/catalog/view/_id" */))
const _5ae5b759 = () => interopDefault(import('../pages/catalog/_id.vue' /* webpackChunkName: "pages/catalog/_id" */))
const _3698ed96 = () => interopDefault(import('../pages/interior/_id.vue' /* webpackChunkName: "pages/interior/_id" */))
const _44524744 = () => interopDefault(import('../pages/pages/_id.vue' /* webpackChunkName: "pages/pages/_id" */))
const _db469fb2 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/blog",
    component: _5a25f4a0,
    name: "blog"
  }, {
    path: "/brends",
    component: _49495806,
    name: "brends"
  }, {
    path: "/cart",
    component: _b9d70ac4,
    name: "cart"
  }, {
    path: "/compare",
    component: _443e077a,
    name: "compare"
  }, {
    path: "/consulting",
    component: _63dbba34,
    name: "consulting"
  }, {
    path: "/designers",
    component: _287d9d00,
    name: "designers"
  }, {
    path: "/favorite",
    component: _5ec18b57,
    name: "favorite"
  }, {
    path: "/cart/order",
    component: _884189cc,
    name: "cart-order"
  }, {
    path: "/catalog/search/notfind",
    component: _857d5154,
    name: "catalog-search-notfind"
  }, {
    path: "/catalog/collection/view/:id?",
    component: _20407fc0,
    name: "catalog-collection-view-id"
  }, {
    path: "/catalog/tile/view/:id?",
    component: _3cba7220,
    name: "catalog-tile-view-id"
  }, {
    path: "/catalog/collection/:id?",
    component: _dc0aab0c,
    name: "catalog-collection-id"
  }, {
    path: "/catalog/search/:name?",
    component: _3b0b7134,
    name: "catalog-search-name"
  }, {
    path: "/catalog/tile/:id?",
    component: _5ab4a54a,
    name: "catalog-tile-id"
  }, {
    path: "/catalog/view/:id?",
    component: _28e5a641,
    name: "catalog-view-id"
  }, {
    path: "/catalog/:id?",
    component: _5ae5b759,
    name: "catalog-id"
  }, {
    path: "/interior/:id?",
    component: _3698ed96,
    name: "interior-id"
  }, {
    path: "/pages/:id?",
    component: _44524744,
    name: "pages-id"
  }, {
    path: "/",
    component: _db469fb2,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
