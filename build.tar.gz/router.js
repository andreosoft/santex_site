import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _98b47038 = () => interopDefault(import('../pages/acceptRules.vue' /* webpackChunkName: "pages/acceptRules" */))
const _5a25f4a0 = () => interopDefault(import('../pages/blog/index.vue' /* webpackChunkName: "pages/blog/index" */))
const _49495806 = () => interopDefault(import('../pages/brends/index.vue' /* webpackChunkName: "pages/brends/index" */))
const _b9d70ac4 = () => interopDefault(import('../pages/cart/index.vue' /* webpackChunkName: "pages/cart/index" */))
const _443e077a = () => interopDefault(import('../pages/compare.vue' /* webpackChunkName: "pages/compare" */))
const _63dbba34 = () => interopDefault(import('../pages/consulting/index.vue' /* webpackChunkName: "pages/consulting/index" */))
const _287d9d00 = () => interopDefault(import('../pages/designers/index.vue' /* webpackChunkName: "pages/designers/index" */))
const _5ec18b57 = () => interopDefault(import('../pages/favorite.vue' /* webpackChunkName: "pages/favorite" */))
const _932436c6 = () => interopDefault(import('../pages/privacy.vue' /* webpackChunkName: "pages/privacy" */))
const _764442f0 = () => interopDefault(import('../pages/publicOffer.vue' /* webpackChunkName: "pages/publicOffer" */))
const _5ee7dd24 = () => interopDefault(import('../pages/sales/index.vue' /* webpackChunkName: "pages/sales/index" */))
const _51ad1358 = () => interopDefault(import('../pages/userAgreement.vue' /* webpackChunkName: "pages/userAgreement" */))
const _884189cc = () => interopDefault(import('../pages/cart/order.vue' /* webpackChunkName: "pages/cart/order" */))
const _09841c70 = () => interopDefault(import('../pages/catalog/getData.js' /* webpackChunkName: "pages/catalog/getData" */))
const _f9e2f2b8 = () => interopDefault(import('../pages/catalog/promotions/index.vue' /* webpackChunkName: "pages/catalog/promotions/index" */))
const _d0611ac8 = () => interopDefault(import('../pages/catalog/search/index.vue' /* webpackChunkName: "pages/catalog/search/index" */))
const _857d5154 = () => interopDefault(import('../pages/catalog/search/notfind.vue' /* webpackChunkName: "pages/catalog/search/notfind" */))
const _20407fc0 = () => interopDefault(import('../pages/catalog/collection/view/_id.vue' /* webpackChunkName: "pages/catalog/collection/view/_id" */))
const _ab332020 = () => interopDefault(import('../pages/catalog/sections/view/_id.vue' /* webpackChunkName: "pages/catalog/sections/view/_id" */))
const _3cba7220 = () => interopDefault(import('../pages/catalog/tile/view/_id.vue' /* webpackChunkName: "pages/catalog/tile/view/_id" */))
const _dc0aab0c = () => interopDefault(import('../pages/catalog/collection/_id.vue' /* webpackChunkName: "pages/catalog/collection/_id" */))
const _62e9476c = () => interopDefault(import('../pages/catalog/sections/_id.vue' /* webpackChunkName: "pages/catalog/sections/_id" */))
const _5ab4a54a = () => interopDefault(import('../pages/catalog/tile/_id.vue' /* webpackChunkName: "pages/catalog/tile/_id" */))
const _28e5a641 = () => interopDefault(import('../pages/catalog/view/_id.vue' /* webpackChunkName: "pages/catalog/view/_id" */))
const _5ae5b759 = () => interopDefault(import('../pages/catalog/_id.vue' /* webpackChunkName: "pages/catalog/_id" */))
const _3698ed96 = () => interopDefault(import('../pages/interior/_id.vue' /* webpackChunkName: "pages/interior/_id" */))
const _44524744 = () => interopDefault(import('../pages/pages/_id.vue' /* webpackChunkName: "pages/pages/_id" */))
const _db469fb2 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/acceptRules",
    component: _98b47038,
    name: "acceptRules"
  }, {
    path: "/blog",
    component: _5a25f4a0,
    name: "blog"
  }, {
    path: "/brends",
    component: _49495806,
    name: "brends"
  }, {
    path: "/cart",
    component: _b9d70ac4,
    name: "cart"
  }, {
    path: "/compare",
    component: _443e077a,
    name: "compare"
  }, {
    path: "/consulting",
    component: _63dbba34,
    name: "consulting"
  }, {
    path: "/designers",
    component: _287d9d00,
    name: "designers"
  }, {
    path: "/favorite",
    component: _5ec18b57,
    name: "favorite"
  }, {
    path: "/privacy",
    component: _932436c6,
    name: "privacy"
  }, {
    path: "/publicOffer",
    component: _764442f0,
    name: "publicOffer"
  }, {
    path: "/sales",
    component: _5ee7dd24,
    name: "sales"
  }, {
    path: "/userAgreement",
    component: _51ad1358,
    name: "userAgreement"
  }, {
    path: "/cart/order",
    component: _884189cc,
    name: "cart-order"
  }, {
    path: "/catalog/getData",
    component: _09841c70,
    name: "catalog-getData"
  }, {
    path: "/catalog/promotions",
    component: _f9e2f2b8,
    name: "catalog-promotions"
  }, {
    path: "/catalog/search",
    component: _d0611ac8,
    name: "catalog-search"
  }, {
    path: "/catalog/search/notfind",
    component: _857d5154,
    name: "catalog-search-notfind"
  }, {
    path: "/catalog/collection/view/:id?",
    component: _20407fc0,
    name: "catalog-collection-view-id"
  }, {
    path: "/catalog/sections/view/:id?",
    component: _ab332020,
    name: "catalog-sections-view-id"
  }, {
    path: "/catalog/tile/view/:id?",
    component: _3cba7220,
    name: "catalog-tile-view-id"
  }, {
    path: "/catalog/collection/:id?",
    component: _dc0aab0c,
    name: "catalog-collection-id"
  }, {
    path: "/catalog/sections/:id?",
    component: _62e9476c,
    name: "catalog-sections-id"
  }, {
    path: "/catalog/tile/:id?",
    component: _5ab4a54a,
    name: "catalog-tile-id"
  }, {
    path: "/catalog/view/:id?",
    component: _28e5a641,
    name: "catalog-view-id"
  }, {
    path: "/catalog/:id?",
    component: _5ae5b759,
    name: "catalog-id"
  }, {
    path: "/interior/:id?",
    component: _3698ed96,
    name: "interior-id"
  }, {
    path: "/pages/:id?",
    component: _44524744,
    name: "pages-id"
  }, {
    path: "/",
    component: _db469fb2,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
